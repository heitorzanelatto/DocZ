import customtkinter as ctk
import openpyxl
from tkinter import filedialog
#from pilot import gerar_doc
import json
import pandas as pd

with open("sistemas.json", "r", encoding="utf-8") as f:
    sistemas_json = json.load(f)

tabela = pd.read_excel("dados_users.xlsx")
analistas_vsc = tabela["Analista VSC"].dropna().astype(str).str.lower().str.title().tolist()
analistas_sistema = tabela["Analista Sistemas"].dropna().astype(str).str.lower().str.title().tolist()
solicitante = tabela["Colaborador"].dropna().astype(str).str.lower().str.title().tolist()
dono_processo = tabela["Colaborador"].dropna().astype(str).str.lower().str.title().tolist()
alt_cor = ["Alteração", "Correção"]
analistas_gq = tabela["Analistas GQ"].dropna().astype(str).str.lower().str.title().tolist()

# Laço de repetição para achar os sistemas
sistemas = []
siglas = [] # é as siglas dos modulos (PP, MM, EWM ....)
processos = []

for i, sistema in enumerate(sistemas_json["sistemas"]):
    sistemas.append(sistema["sistema"])

# Caminho do Excel
CAMINHO_EXCEL = r"C:\Users\organex.heitor\Desktop\Docz\Dados.xlsx"
pasta = ""

# Função para selecionar o local do arquivo
def local_arquivo():
    global pasta
    pasta = filedialog.askdirectory(title="Selecione a pasta onde deseja salvar")
    print("📂 Pasta escolhida:", pasta)

# Função para gerar os documentos
def chamar_pilot():
    global pasta
    if not pasta:
        print("⚠️ Selecione a pasta antes de gerar os documentos!")
        return
    gerar_doc(CAMINHO_EXCEL, pasta)

# Função para gravar informação
def gravar_info():
    
    '''
    valores = {
        "C2": campo_nome_sistema.get(),
        "D2": campo_numero_cs.get(),
        #"E2": campo_cod_sistema.get(),
        "F2": campo_cod_ef.get(),
        "G2": campo_numero_cm.get(),
        "H2": campo_modulo.get(),
        #"I2": campo_desc_modulo.get(),
        "K2": campo_processo.get().lower(), # processo precisa ser maiusculo e minusculo
        #"J2": campo_processo.get().upper(),******* VERIFICAR **********
        "L2": campo_alt_cor.get(),     
        #"M2": campo_desc_cs.get(),
        "N2": campo_nome_analista_vsc.get(),
        "O2": campo_nome_analista_sist.get(),
        #"P2": campo_cargo_analista_sist.get(),
        "Q2": campo_nome_analista_gq.get(),
        "R2": campo_nome_user_solic.get(),
        #"S2": campo_cargo_user_solic.get(), 
        "T2": campo_nome_user_proc.get(),
        #"U2": campo_cargo_user_proc.get(),
        #"V2": campo_nome_coord_vsc.get(),
        #"W2": campo_nome_coord_sist.get(),
        #"X2": campo_cargo_coord_sist.get(),
        #"Y2": campo_nome_coord_solic.get(),
        #"Z2": campo_cargo_coord_solic.get(),
        #"AA2": campo_nome_coord_gq.get(),
        #"AB2": campo_nome_coord_proc.get(),
        #"AC2": campo_cargo_coord_proc.get(),

        #"O2": campo_cargo_analista_vsc.get(),** deixar fixo no doc
        #"Q2": campo_cargo_coord_vsc.get(), ** deixar fixo no doc       
        #"AE2": campo_cargo_analista_gq.get(), ** deixar fixo no doc 
        #"AG2": campo_cargo_coord_gq.get() ** deixar fixo no doc 
    }
    '''
    wb = openpyxl.load_workbook(CAMINHO_EXCEL)
    ws = wb.active
    for celula, valor in valores.items():
        ws[celula] = valor
    wb.save(CAMINHO_EXCEL)
    print('Valores Gravados')

# Criação da Janela
app = ctk.CTk()
app.title('DocZ')
app.geometry('450x650')
app.minsize(width= 450, height= 650)
app.grid_rowconfigure(0, weight=1)
app.grid_columnconfigure(0, weight=1)

padrão_font_label_titulo = ("Roboto", 18, "bold")
estilo_combo = {"fg_color": "#3B8ED0", "border_color": "#3B8ED0", "button_color": "#36719F", "button_hover_color": "#27577d", "text_color": "#E7E7E7", "corner_radius": 6}
estilo_entry = {"fg_color": "#3B8ED0", "border_color": "#3B8ED0", "text_color": "#E7E7E7", "corner_radius": 6}
padrão_font = ("Roboto", 13, "bold")

# Frame principal
frame_principal = ctk.CTkFrame(app)
frame_principal.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)
frame_principal.grid_rowconfigure(0, weight=1)
frame_principal.grid_columnconfigure(0, weight=1)

# Subframe para campos
subframe_campos = ctk.CTkFrame(frame_principal)
subframe_campos.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
for i in range(13):
    subframe_campos.grid_rowconfigure(i, weight=1)
for j in range(2):
    subframe_campos.grid_columnconfigure(j, weight=1)

# Função auxiliar para criar campos
def criar_campo(label_text, row, column):
    fonte_padrao = (padrão_font) #"Roboto", 13, "bold"
    #label = ctk.CTkLabel(subframe_campos, text=label_text, bg_color="red")
    #label.grid(row=row, column=column, padx= 10, pady=5, sticky="w")
    entry = ctk.CTkEntry(subframe_campos, placeholder_text = label_text, font= fonte_padrao, **estilo_entry, placeholder_text_color= "#E7E7E7")
    entry.grid(row=row+1, column=column, padx= 10, pady=3, sticky="ew", columnspan=2)
    #fonte = entry.cget("font")
    #print(f"Família da fonte: {fonte.cget('family')}")
    #print(f"Tamanho da fonte: {fonte.cget('size')}")
    #print(f"Peso da fonte: {fonte.cget('weight')}")
    return entry

# FUNÇÕES DE CONDICIONAMENTOS
def sistema_selecionado(opcao_sistema):
    droplist_modulo.set('Selecione o Módulo')
    droplist_processo.set('Selecione o Processo')
    siglas.clear()

    sistema_index = sistemas.index(droplist_sistema.get()) # encontra o indice do sistema selecionado

    for modulo in sistemas_json["sistemas"][sistema_index]["modulos"]:
        siglas.append(modulo["sigla"])

    print(f"Você selecionou: {opcao_sistema}")

    if siglas:
        droplist_modulo.configure(values=siglas)
    else:
        droplist_modulo.configure(values=[""])

def modulo_selecionado(opcao_modulo):
    droplist_processo.set('Selecione o Processo')
    processos.clear()

    sistema_index = sistemas.index(droplist_sistema.get()) #pega o indice dos sistemas no json
    modulo_index = siglas.index(droplist_modulo.get()) #pega o indice dos modulos no json

    #print(sistemas_json["sistemas"][sistema_index]["modulos"][modulo_index])

    for processo in sistemas_json["sistemas"][sistema_index]["modulos"][modulo_index]["processos"]:
        processos.append(processo)

    print(f"Você selecionou o modulo: {opcao_modulo}")

    if processos:
        droplist_processo.configure(values=processos)
    else:
        droplist_processo.configure(values=[""])



# Função chamada quando seleciona um nome
def selecionar_analista_vsc(valor_analista_vsc):
    if valor_analista_vsc in analistas_vsc:
        index_analistas_vsc = analistas_vsc.index(valor_analista_vsc)
        print(f"Selecionado: {valor_analista_vsc} | Índice na lista: {index_analistas_vsc}")
        cargo_analista_vsc = tabela.loc[index_analistas_vsc, "Cargo Analista VSC"]
        print(f"Cargo Analista VSC: {cargo_analista_vsc}")
    else:
        None

# Função para atualizar sugestões enquanto digita
def filtrar_analista_sistema(event):
    texto = entry_combo_analista_sistema.get().lower()
    palavras = texto.split()  # separa em palavras (ex: "Douglas Luppi" -> ["douglas","luppi"])

    sugestoes = []
    for nome in analistas_sistema:
        nome_lower = nome.lower()
        # verifica se TODAS as palavras digitadas existem no nome
        if all(p in nome_lower for p in palavras):
            sugestoes.append(nome)

    # atualiza lista de sugestões
    entry_combo_analista_sistema.configure(values=sugestoes if sugestoes else analistas_sistema)

# Função chamada quando seleciona um nome
def selecionar_analista_sistema(valor):
    if valor in analistas_sistema:
        index_analista_sistema = analistas_sistema.index(valor)
        print(f"Selecionado: {valor} | Índice na lista: {index_analista_sistema}")
        cargo_analista_sistema = tabela.loc[index_analista_sistema, "Cargos dos Analistas de Sistemas"]
        print(f"Cargo Colaborador: {cargo_analista_sistema}")
        nome_superior = tabela.loc[index_analista_sistema, "Coordenadores Sistemas"]
        print(f"Nome Superior: {nome_superior}")
        cargo_superior = tabela.loc[index_analista_sistema, "Cargo Coordenador Sistemas"]
        print(f"Cargo Superior: {cargo_superior}")
    else:
        None

# Função para atualizar sugestões enquanto digita
def filtrar_solicitante(event):
    texto = entry_combo_solicitante.get().lower()
    palavras = texto.split()  # separa em palavras (ex: "Douglas Luppi" -> ["douglas","luppi"])

    sugestoes = []
    for nome in solicitante:
        nome_lower = nome.lower()
        # verifica se TODAS as palavras digitadas existem no nome
        if all(p in nome_lower for p in palavras):
            sugestoes.append(nome)

    # atualiza lista de sugestões
    entry_combo_solicitante.configure(values=sugestoes if sugestoes else solicitante)

# Função chamada quando seleciona um nome
def selecionar_solicitante(valor):
    if valor in solicitante:
        index_colaborador = solicitante.index(valor)
        print(f"Selecionado: {valor} | Índice na lista: {index_colaborador}")
        cargo_colaborador = tabela.loc[index_colaborador, "Cargo"].title()
        print(f"Cargo Colaborador: {cargo_colaborador}")
        nome_superior = tabela.loc[index_colaborador, "Superior"].title()
        print(f"Nome Superior: {nome_superior}")
        cargo_superior = tabela.loc[index_colaborador, "Cargo Superior"].title()
        print(f"Cargo Superior: {cargo_superior}")
    else:
        None

# Função para atualizar sugestões enquanto digita
def filtrar_dono_processo(event):
    texto = entry_combo_dono_processo.get().lower()
    palavras = texto.split()  # separa em palavras (ex: "Douglas Luppi" -> ["douglas","luppi"])

    sugestoes = []
    for nome in dono_processo:
        nome_lower = nome.lower()
        # verifica se TODAS as palavras digitadas existem no nome
        if all(p in nome_lower for p in palavras):
            sugestoes.append(nome)

    # atualiza lista de sugestões
    entry_combo_dono_processo.configure(values=sugestoes if sugestoes else dono_processo)

# Função chamada quando seleciona um nome
def selecionar_dono_processo(valor):
    if valor in dono_processo:
        index_dono_processo = dono_processo.index(valor)
        print(f"Selecionado: {valor} | Índice na lista: {index_dono_processo}")
        cargo_dono_processo = tabela.loc[index_dono_processo, "Cargo"].title()
        print(f"Cargo Colaborador: {cargo_dono_processo}")
        nome_superior = tabela.loc[index_dono_processo, "Superior"].title()
        print(f"Nome Superior: {nome_superior}")
        cargo_superior = tabela.loc[index_dono_processo, "Cargo Superior"].title()
        print(f"Cargo Superior: {cargo_superior}")
    else:
        None

# ----------------------------------------------------------------------------------------------------------------------------------------#

# Campos
droplist_sistema = ctk.CTkOptionMenu(subframe_campos, values=sistemas, command=sistema_selecionado, font=padrão_font, text_color= "#E7E7E7" )
droplist_sistema.grid(row=1, column=0, padx= 10, pady=3, sticky="ew", columnspan=2)
droplist_sistema.set("Selecione o Sistema")

droplist_modulo = ctk.CTkOptionMenu(subframe_campos, values="", command=modulo_selecionado, font=padrão_font)
droplist_modulo.grid(row=3, column=0, padx= 10, pady=3, sticky="ew", columnspan=2)
droplist_modulo.set("Selecione o Módulo")

droplist_processo = ctk.CTkOptionMenu(subframe_campos, values="", command=None, font=padrão_font)
droplist_processo.grid(row=4, column=0, padx= 10, pady=3, sticky="ew", columnspan=2)
droplist_processo.set("Selecione o Processo")

droplist_alt_cor = ctk.CTkOptionMenu(subframe_campos, values=alt_cor, command=None, font=padrão_font)
droplist_alt_cor.grid(row=5, column=0, padx= 10, pady=3, sticky="ew", columnspan=2)
droplist_alt_cor.set("Alteração ou Correção:")

droplist_vsc = ctk.CTkOptionMenu(subframe_campos, values=analistas_vsc, command=selecionar_analista_vsc, font=padrão_font)
droplist_vsc.grid(row=8, column=0, padx= 10, pady=3, sticky="ew", columnspan=2)
droplist_vsc.set("Nome Analista VSC")

entry_combo_analista_sistema = ctk.CTkComboBox(subframe_campos, values=analistas_sistema, command=selecionar_analista_sistema, **estilo_combo, font=padrão_font)
entry_combo_analista_sistema.grid(row=9, column=0, padx= 10, pady=3, sticky="ew", columnspan=2)
entry_combo_analista_sistema.set("Nome Analista Sistema:")
# Detecta digitação
entry_combo_analista_sistema.bind("<KeyRelease>", filtrar_analista_sistema)

entry_combo_solicitante = ctk.CTkComboBox(subframe_campos, values=solicitante, command=selecionar_solicitante, **estilo_combo, font=padrão_font)
entry_combo_solicitante.grid(row=10, column=0, padx= 10, pady=3, sticky="ew", columnspan=2)
entry_combo_solicitante.set("Nome Usuário Solicitante:")
# Detecta digitação
entry_combo_solicitante.bind("<KeyRelease>", filtrar_solicitante)

entry_combo_dono_processo = ctk.CTkComboBox(subframe_campos, values=solicitante, command=selecionar_solicitante, **estilo_combo, font=padrão_font)
entry_combo_dono_processo.grid(row=11, column=0, padx= 10, pady=3, sticky="ew", columnspan=2)
entry_combo_dono_processo.set("Nome Usuário Solicitante:")
# Detecta digitação
entry_combo_dono_processo.bind("<KeyRelease>", filtrar_solicitante)

droplist_analista_gq = ctk.CTkOptionMenu(subframe_campos, values=analistas_gq, command=None, font=padrão_font)
droplist_analista_gq.grid(row=12, column=0, padx= 10, pady=3, sticky="ew", columnspan=2)
droplist_analista_gq.set("Nome Analista GQ:")

#campo_nome_sistema = criar_campo("Nome do Sistema:", 0, 0)
campo_numero_cs = criar_campo("Número do Chamado (CS):", 1, 0)
#campo_cod_sistema = criar_campo("Código do Sistema:", 2, 0)
#campo_modulo = criar_campo("Módulo:", 2, 0)
#campo_desc_modulo = criar_campo("Descrição do Módulo:", 4, 0)
#campo_processo = criar_campo("Processo:", 3, 0)
#campo_alt_cor = criar_campo("Alteração ou Correção:", 4, 0)
campo_numero_cm = criar_campo("Número do CM:", 5, 0)
campo_cod_ef = criar_campo("Código da EF:", 6, 0)
#campo_desc_cs = criar_campo("Descrição do CS:", 9, 0)
#campo_nome_analista_vsc = criar_campo("Nome Analista VSC:", 7, 0)
#campo_cargo_analista_vsc = criar_campo("Cargo Analista VSC:", 11, 0)
#campo_nome_coord_vsc = criar_campo("Nome Coord. VSC:", 12, 0)
#campo_cargo_coord_vsc = criar_campo("Cargo Coord. VSC:", 13, 0)
#campo_nome_analista_sist = criar_campo("Nome Analista Sistemas:", 8, 0)
#campo_cargo_analista_sist = criar_campo("Cargo Analista Sistemas:", 15, 0)
#campo_nome_coord_sist = criar_campo("Nome Coord. Sistemas:", 16, 0)
#campo_cargo_coord_sist = criar_campo("Cargo Coord. Sistemas:", 17, 0)
#campo_nome_user_solic = criar_campo("Nome Usuário Solicitante:", 9, 0)
#campo_cargo_user_solic = criar_campo("Cargo Usuário Solicitante:", 19, 0)
#campo_nome_coord_solic = criar_campo("Nome Coord. Solicitante:", 0, 2)
#campo_cargo_coord_solic = criar_campo("Cargo Coord. Solicitante:", 1, 2)
#campo_nome_user_proc = criar_campo("Nome Usuário Dono Processo:", 10, 0)
#campo_cargo_user_proc = criar_campo("Cargo Usuário Dono Processo:", 3, 2)
#campo_nome_coord_proc = criar_campo("Nome Coord. Dono Processo:", 4, 2)
#campo_cargo_coord_proc = criar_campo("Cargo Coord. Dono Processo:", 5, 2)
#campo_nome_analista_gq = criar_campo("Nome Analista GQ:", 11, 0)
#campo_cargo_analista_gq = criar_campo("Cargo Analista GQ:", 7, 2)
#campo_nome_coord_gq = criar_campo("Nome Coord. GQ:", 8, 2)
#campo_cargo_coord_gq = criar_campo("Cargo Coord. GQ:", 9, 2)

# Subframe para os entrys
titulo_entry = ctk.CTkLabel(subframe_campos, text='DOCUMENTOS', font= padrão_font_label_titulo)
titulo_entry.grid (row=0, column=0, padx=2, pady=10, sticky="nsew", columnspan=2)

# Subframe para botões
subframe_botoes = ctk.CTkFrame(frame_principal)
subframe_botoes.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
subframe_botoes.grid_columnconfigure((0, 1), weight=1)

#Subframe titulo botões
titulo_botoes = ctk.CTkLabel(subframe_botoes, text='GERENCIAMENTO', font= padrão_font_label_titulo)
titulo_botoes.grid (row=0, column=0, padx=10, pady=(10), sticky="nsew", columnspan = 2)

botao_local_arquivo = ctk.CTkButton(subframe_botoes, text='Local do Arquivo', command=local_arquivo, font=padrão_font)
botao_local_arquivo.grid(row=1, column=0, padx=10, pady=5, sticky="ew")

botao_salvar = ctk.CTkButton(subframe_botoes, text='Salvar Informações', command=gravar_info, font=padrão_font)
botao_salvar.grid(row=1, column=1, padx=10, pady=5, sticky="ew")

botao_gerar = ctk.CTkButton(subframe_botoes, text='Gerar Documentos', command=chamar_pilot, font=padrão_font)
botao_gerar.grid(row=2, column=0, padx=10, pady=(5,10), sticky="ew", columnspan=2)

# CONDICIONAMENTOS

#if campo_nome_analista_vsc == "ERP SAP S/4 HANA":
#    print ("SAP")
    


# Iniciar aplicação
app.mainloop()

