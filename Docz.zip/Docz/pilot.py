# Importando as bibliotecas necessárias
from docx import Document
import pandas as pd
import os

def gerar_doc(CAMINHO_EXCEL, pasta_saida):

    # Caminho da planilha com as informações
    #caminho_planilha = CAMINHO_EXCEL
    #print (f'local selecionado: {caminho_planilha}')

    # Lê a planilha inteira
    tabela = pd.read_excel(CAMINHO_EXCEL)

    # ---- Passo 1: Pegar os valores da linha 2 (índice 0 no Python) ----
    linha2 = tabela.iloc[0]

    # Criar um dicionário para guardar as substituições
    substituicoes = {}

    # Vamos começar da coluna C em diante (índice 2)
    for nome_coluna in linha2.index[2:]:
        valor = linha2[nome_coluna]

        # Se for número inteiro (ex: 10.0), transforma em "10"
        if isinstance(valor, float) and valor.is_integer():
            valor = int(valor)

        # Guarda no dicionário como texto
        substituicoes[str(nome_coluna)] = str(valor)

    # ---- Passo 2: Percorrer todas as linhas da planilha ----
    for i, linha in tabela.iterrows():
        # Coluna A tem o caminho do modelo
        caminho_modelo = linha["MODELO"]

        # Coluna B tem o nome do arquivo para salvar
        nome_salvar = linha["NOME DO ARQUIVO SALVO"]

        # Abrir o documento modelo
        documento = Document(caminho_modelo)

        # ---- Substituir nos parágrafos ----
        for paragrafo in documento.paragraphs:
            for run in paragrafo.runs:
                for chave, valor in substituicoes.items():
                    if chave in run.text:
                        run.text = run.text.replace(chave, valor)

        # ---- Substituir nos cabeçalhos ----
        for secao in documento.sections:
            for paragrafo in secao.header.paragraphs:
                for run in paragrafo.runs:
                    for chave, valor in substituicoes.items():
                        if chave in run.text:
                            run.text = run.text.replace(chave, valor)

        # ---- Substituir nos rodapés ----
        for secao in documento.sections:
            for paragrafo in secao.footer.paragraphs:
                for run in paragrafo.runs:
                    for chave, valor in substituicoes.items():
                        if chave in run.text:
                            run.text = run.text.replace(chave, valor)

        # ---- Substituir dentro das tabelas ----
        for tabela_doc in documento.tables:
            for linha_tabela in tabela_doc.rows:
                for celula in linha_tabela.cells:
                    for paragrafo in celula.paragraphs:
                        for run in paragrafo.runs:
                            for chave, valor in substituicoes.items():
                                if chave in run.text:
                                    run.text = run.text.replace(chave, valor)

        # ---- Substituir em tabelas nos cabeçalhos ----
        for secao in documento.sections:
            for tabela in secao.header.tables:
                for linha in tabela.rows:
                    for celula in linha.cells:
                        for paragrafo in celula.paragraphs:
                            for run in paragrafo.runs:
                                for chave, valor in substituicoes.items():
                                    if chave in run.text:
                                        run.text = run.text.replace(chave, valor)

        caminho_saida = os.path.join(pasta_saida, f"{nome_salvar}.docx")
        documento.save(caminho_saida)
        print(f"✅ Documento salvo em: {caminho_saida}")

'''
        # ---- Substituir nos parágrafos ----
        for paragrafo in documento.paragraphs:
            for chave, valor in substituicoes.items():
                if chave in paragrafo.text:
                    paragrafo.text = paragrafo.text.replace(chave, valor)

        # ---- Substituir nos cabeçalhos ----
        for secao in documento.sections:
            for paragrafo in secao.header.paragraphs:
                for chave, valor in substituicoes.items():
                    if chave in paragrafo.text:
                        paragrafo.text = paragrafo.text.replace(chave, valor)

        # ---- Substituir nos rodapés ----
        for secao in documento.sections:
            for paragrafo in secao.footer.paragraphs:
                for chave, valor in substituicoes.items():
                    if chave in paragrafo.text:
                        paragrafo.text = paragrafo.text.replace(chave, valor)

            # ---- Substituir dentro das tabelas ----
        for tabela_doc in documento.tables:
            for linha_tabela in tabela_doc.rows:
                for celula in linha_tabela.cells:
                    for chave, valor in substituicoes.items():
                        if chave in celula.text:
                            celula.text = celula.text.replace(chave, valor)
       

        # ---- Substituir em tabelas nos cabeçalhos ----
        for secao in documento.sections:
            for tabela in secao.header.tables:
                for linha in tabela.rows:
                    for celula in linha.cells:
                        for chave, valor in substituicoes.items():
                            if chave in celula.text:
                                celula.text = celula.text.replace(chave, valor)
'''



        # Defina a pasta onde salvar os documentos
        #pasta_saida = pasta
'''
        # Salva o documento no local definido
        caminho_saida = os.path.join(pasta_saida, f"{nome_salvar}.docx")
        documento.save(caminho_saida)
        print(f"✅ Documento salvo em: {caminho_saida}")
'''