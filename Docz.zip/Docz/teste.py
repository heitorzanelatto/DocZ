import customtkinter as ctk
import pandas as pd

# Carregar planilha
tabela = pd.read_excel("dados_users.xlsx")
solicitante = tabela["Colaborador"].dropna().astype(str).str.lower().str.title().tolist()
dono_processo = tabela["Colaborador"].dropna().astype(str).str.lower().str.title().tolist()
analistas_vsc = tabela["Analista VSC"].dropna().astype(str).str.lower().str.title().tolist()
analistas_sistema = tabela["Analista Sistemas"].dropna().astype(str).str.lower().str.title().tolist()

# Função para atualizar sugestões enquanto digita
def filtrar_solicitante(event):
    texto = entry_combo_solicitante.get().lower()
    palavras = texto.split()  # separa em palavras (ex: "Douglas Luppi" -> ["douglas","luppi"])

    sugestoes = []
    for nome in solicitante:
        nome_lower = nome.lower()
        # verifica se TODAS as palavras digitadas existem no nome
        if all(p in nome_lower for p in palavras):
            sugestoes.append(nome)

    # atualiza lista de sugestões
    entry_combo_solicitante.configure(values=sugestoes if sugestoes else solicitante)

# Função chamada quando seleciona um nome
def selecionar_solicitante(valor):
    if valor in solicitante:
        index_colaborador = solicitante.index(valor)
        print(f"Selecionado: {valor} | Índice na lista: {index_colaborador}")
        cargo_colaborador = tabela.loc[index_colaborador, "Cargo"].title()
        print(f"Cargo Colaborador: {cargo_colaborador}")
        nome_superior = tabela.loc[index_colaborador, "Superior"].title()
        print(f"Nome Superior: {nome_superior}")
        cargo_superior = tabela.loc[index_colaborador, "Cargo Superior"].title()
        print(f"Cargo Superior: {cargo_superior}")
    else:
        None


# Função para atualizar sugestões enquanto digita
def filtrar_dono_processo(event):
    texto = entry_combo_dono_processo.get().lower()
    palavras = texto.split()  # separa em palavras (ex: "Douglas Luppi" -> ["douglas","luppi"])

    sugestoes = []
    for nome in dono_processo:
        nome_lower = nome.lower()
        # verifica se TODAS as palavras digitadas existem no nome
        if all(p in nome_lower for p in palavras):
            sugestoes.append(nome)

    # atualiza lista de sugestões
    entry_combo_dono_processo.configure(values=sugestoes if sugestoes else dono_processo)

# Função chamada quando seleciona um nome
def selecionar_dono_processo(valor):
    if valor in dono_processo:
        index_dono_processo = dono_processo.index(valor)
        print(f"Selecionado: {valor} | Índice na lista: {index_dono_processo}")
        cargo_dono_processo = tabela.loc[index_dono_processo, "Cargo"].title()
        print(f"Cargo Colaborador: {cargo_dono_processo}")
        nome_superior = tabela.loc[index_dono_processo, "Superior"].title()
        print(f"Nome Superior: {nome_superior}")
        cargo_superior = tabela.loc[index_dono_processo, "Cargo Superior"].title()
        print(f"Cargo Superior: {cargo_superior}")
    else:
        None


# Função para atualizar sugestões enquanto digita
def filtrar_analista_vsc(event):
    texto = entry_combo_vsc.get().lower()
    palavras = texto.split()  # separa em palavras (ex: "Douglas Luppi" -> ["douglas","luppi"])

    sugestoes = []
    for nome in analistas_vsc:
        nome_lower = nome.lower()
        # verifica se TODAS as palavras digitadas existem no nome
        if all(p in nome_lower for p in palavras):
            sugestoes.append(nome)

    # atualiza lista de sugestões
    entry_combo_vsc.configure(values=sugestoes if sugestoes else analistas_vsc)

# Função chamada quando seleciona um nome
def selecionar_analista_vsc(valor):
    if valor in analistas_vsc:
        index_analistas_vsc = analistas_vsc.index(valor)
        print(f"Selecionado: {valor} | Índice na lista: {index_analistas_vsc}")
        cargo_analista_vsc = tabela.loc[index_analistas_vsc, "Cargo Analista VSC"]
        print(f"Cargo Analista VSC: {cargo_analista_vsc}")
    else:
        None
        

# Função para atualizar sugestões enquanto digita
def filtrar_analista_sistema(event):
    texto = entry_combo_analista_sistema.get().lower()
    palavras = texto.split()  # separa em palavras (ex: "Douglas Luppi" -> ["douglas","luppi"])

    sugestoes = []
    for nome in analistas_sistema:
        nome_lower = nome.lower()
        # verifica se TODAS as palavras digitadas existem no nome
        if all(p in nome_lower for p in palavras):
            sugestoes.append(nome)

    # atualiza lista de sugestões
    entry_combo_analista_sistema.configure(values=sugestoes if sugestoes else analistas_sistema)

# Função chamada quando seleciona um nome
def selecionar_analista_sistema(valor):
    if valor in analistas_sistema:
        index_analista_sistema = analistas_sistema.index(valor)
        print(f"Selecionado: {valor} | Índice na lista: {index_analista_sistema}")
        cargo_analista_sistema = tabela.loc[index_analista_sistema, "Cargos dos Analistas de Sistemas"]
        print(f"Cargo Colaborador: {cargo_analista_sistema}")
        nome_superior = tabela.loc[index_analista_sistema, "Coordenadores Sistemas"]
        print(f"Nome Superior: {nome_superior}")
        cargo_superior = tabela.loc[index_analista_sistema, "Cargo Coordenador Sistemas"]
        print(f"Cargo Superior: {cargo_superior}")
    else:
        None


# Interface
app = ctk.CTk()
app.title("DocZ")
app.geometry("450x450")

estilo_combo = {"fg_color": "#3B8ED0", "border_color": "#3B8ED0", "button_color": "#36719F", "button_hover_color": "#27577d", "text_color": "white", "corner_radius": 6}

# Criar combobox com digitação
entry_combo_solicitante = ctk.CTkComboBox(app, values=solicitante, command=selecionar_solicitante, width=350, **estilo_combo)
entry_combo_solicitante.grid(row=0, column=0, padx=10, pady=10)
entry_combo_solicitante.set("Nome Usuário Solicitante:")
# Detecta digitação
entry_combo_solicitante.bind("<KeyRelease>", filtrar_solicitante)

# Criar combobox com digitação
entry_combo_dono_processo = ctk.CTkComboBox(app, values=dono_processo, command=selecionar_dono_processo, width=350, **estilo_combo)
entry_combo_dono_processo.grid(row=1, column=0, padx=10, pady=10)
entry_combo_dono_processo.set("Nome Usuário Dono do Processo:")
# Detecta digitação
entry_combo_dono_processo.bind("<KeyRelease>", filtrar_dono_processo)

# Criar combobox com digitação
entry_combo_vsc = ctk.CTkOptionMenu(app, values=analistas_vsc, command=selecionar_analista_vsc, width=350)
entry_combo_vsc.grid(row=2, column=0, padx=10, pady=10)
entry_combo_vsc.set("Nome Analista VSC:")
# Detecta digitação
entry_combo_vsc.bind("<KeyRelease>", filtrar_analista_vsc)

# Criar combobox com digitação
entry_combo_analista_sistema = ctk.CTkComboBox(app, values=analistas_sistema, command=selecionar_analista_sistema, width=350, **estilo_combo)
entry_combo_analista_sistema.grid(row=3, column=0, padx=10, pady=10)
entry_combo_analista_sistema.set("Nome Analista Sistema:")
# Detecta digitação
entry_combo_analista_sistema.bind("<KeyRelease>", filtrar_analista_sistema)

app.mainloop()

